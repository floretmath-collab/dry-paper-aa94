GWADAPROJET V15 — STRIPE SERVEUR

Cette version remplace le paiement de démonstration par un Checkout Stripe réel et vérifie le paiement côté serveur avant de débloquer les offres.

Offres :
- 29,90 € : analyse détaillée, seuil, scénarios, trésorerie et plan d'action.
- 49,90 € : niveau précédent + business plan premium + PDF.

Lis SETUP_STRIPE.txt avant le déploiement.
