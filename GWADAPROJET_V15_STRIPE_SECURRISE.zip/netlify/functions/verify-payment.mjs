import { json, getSecrets, signEntitlement } from "./_auth.mjs";

export default async (req) => {
  try{
    const {stripe,entitlement}=getSecrets();
    const u=new URL(req.url);
    const id=u.searchParams.get("session_id")||"";
    if(!/^cs_/.test(id)) return json({error:"Session Stripe invalide."},400);
    const r=await fetch("https://api.stripe.com/v1/checkout/sessions/"+encodeURIComponent(id),{
      headers:{"authorization":`Bearer ${stripe}`}
    });
    const s=await r.json();
    if(!r.ok) return json({error:s?.error?.message||"Session Stripe introuvable."},502);
    const plan=s?.metadata?.plan;
    if(s.payment_status!=="paid" || !["basic","advanced"].includes(plan)){
      return json({error:"Le paiement n'est pas confirmé."},402);
    }
    const token=signEntitlement({
      v:1,plan,session_id:s.id,email:s.customer_details?.email||s.customer_email||"",
      iat:Date.now(),exp:Date.now()+1000*60*60*24*365
    },entitlement);
    return json({paid:true,plan,token});
  }catch(e){ return json({error:e.message||"Erreur serveur."},500); }
};
