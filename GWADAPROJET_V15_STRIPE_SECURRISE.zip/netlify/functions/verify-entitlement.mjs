import { json, getSecrets, verifyEntitlement, rank } from "./_auth.mjs";

export default async (req) => {
  if(req.method!=="POST") return json({error:"Méthode non autorisée."},405);
  try{
    const {entitlement}=getSecrets();
    const body=await req.json();
    const payload=verifyEntitlement(body.token,entitlement);
    if(!payload || !["basic","advanced"].includes(payload.plan)) return json({valid:false},401);
    const required=body.requiredPlan;
    if(required && rank(payload.plan)<rank(required)) return json({valid:false,plan:payload.plan},403);
    return json({valid:true,plan:payload.plan,expiresAt:payload.exp});
  }catch(e){ return json({error:e.message||"Erreur serveur."},500); }
};
