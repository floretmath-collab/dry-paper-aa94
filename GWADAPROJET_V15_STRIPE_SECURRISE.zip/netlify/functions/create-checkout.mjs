import { json, getSecrets } from "./_auth.mjs";

const PRODUCTS={
  basic:{amount:2990,name:"GWADAPROJET — Plan complet 29,90 €"},
  advanced:{amount:4990,name:"GWADAPROJET — Business plan + prévisionnel 49,90 €"}
};

export default async (req) => {
  if(req.method!=="POST") return json({error:"Méthode non autorisée."},405);
  try{
    const {stripe}=getSecrets();
    const body=await req.json();
    const plan=body.plan;
    const product=PRODUCTS[plan];
    const email=String(body.email||"").trim().slice(0,254);
    const name=String(body.name||"").trim().slice(0,120);
    if(!product || !email || !name) return json({error:"Offre, nom ou e-mail invalide."},400);
    const base=(process.env.URL || new URL(req.url).origin).replace(/\/$/,"");
    const form=new URLSearchParams();
    form.set("mode","payment");
    form.set("success_url",`${base}/?payment=success&session_id={CHECKOUT_SESSION_ID}`);
    form.set("cancel_url",`${base}/?payment=cancelled`);
    form.set("customer_email",email);
    form.set("client_reference_id",plan+"-"+Date.now());
    form.set("metadata[plan]",plan);
    form.set("metadata[customer_name]",name);
    form.set("line_items[0][quantity]","1");
    form.set("line_items[0][price_data][currency]","eur");
    form.set("line_items[0][price_data][unit_amount]",String(product.amount));
    form.set("line_items[0][price_data][product_data][name]",product.name);
    const r=await fetch("https://api.stripe.com/v1/checkout/sessions",{
      method:"POST",
      headers:{"authorization":`Bearer ${stripe}`,"content-type":"application/x-www-form-urlencoded"},
      body:form
    });
    const data=await r.json();
    if(!r.ok) return json({error:data?.error?.message||"Stripe a refusé la création du paiement."},502);
    return json({url:data.url});
  }catch(e){ return json({error:e.message||"Erreur serveur."},500); }
};
