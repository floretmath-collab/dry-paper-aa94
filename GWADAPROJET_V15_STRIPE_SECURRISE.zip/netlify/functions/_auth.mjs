import crypto from "node:crypto";

export const json = (data, status=200) => new Response(JSON.stringify(data), {
  status, headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}
});

export function getSecrets(){
  const stripe=process.env.STRIPE_SECRET_KEY;
  const entitlement=process.env.GWADA_ENTITLEMENT_SECRET;
  if(!stripe) throw new Error("STRIPE_SECRET_KEY manquante dans Netlify.");
  if(!entitlement || entitlement.length < 32) throw new Error("GWADA_ENTITLEMENT_SECRET manquante ou trop courte (32 caractères minimum).");
  return {stripe, entitlement};
}

export function signEntitlement(payload, secret){
  const body=Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig=crypto.createHmac("sha256",secret).update(body).digest("base64url");
  return body+"."+sig;
}
export function verifyEntitlement(token, secret){
  if(!token || !token.includes(".")) return null;
  const [body,sig]=token.split(".");
  const expected=crypto.createHmac("sha256",secret).update(body).digest("base64url");
  const a=Buffer.from(sig); const b=Buffer.from(expected);
  if(a.length!==b.length || !crypto.timingSafeEqual(a,b)) return null;
  const payload=JSON.parse(Buffer.from(body,"base64url").toString("utf8"));
  if(payload.exp && Date.now()>payload.exp) return null;
  return payload;
}
export function rank(plan){ return plan==="advanced"?2:plan==="basic"?1:0; }
